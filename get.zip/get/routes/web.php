<?php

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/entrar', 'EntrarController@index');
Route::post('/entrar', 'EntrarController@entrar');
Route::get('/registrar', 'RegistroController@create');
Route::post('/registrar', 'RegistroController@store');

Route::get('/sair', function () {
    \Illuminate\Support\Facades\Auth::logout();
    return redirect('/entrar');
});

Route::get('/produtos', 'ProdutosController@index')
    ->name('listar_produtos')
    ->middleware('autenticador');
Route::get('/produtos/criar', 'ProdutosController@create')
    ->name('form_criar_produto');
Route::post('/produtos/criar', 'ProdutosController@store');
Route::delete('/produtos/remover/{id}', 'ProdutosController@destroy');

Route::get('/clientes', 'ClientesController@index')
    ->name('listar_clientes');
Route::get('/clientes/criar', 'ClientesController@create')
    ->name('form_criar_cliente');
Route::get('/clientes/{id}/show', 'ClientesController@show');
Route::post('/clientes/criar', 'ClientesController@store');
Route::delete('/clientes/remover/{id}', 'ClientesController@destroy');

Route::get('/funcionarios', 'FuncionariosController@index')
    ->name('listar_funcionarios');
Route::get('/funcionarios/criar', 'FuncionariosController@create')
    ->name('form_criar_funcionario');
Route::post('/funcionarios/criar', 'FuncionariosController@store');
Route::delete('/funcionarios/remover/{id}', 'FuncionariosController@destroy');

Route::get('/caixas', 'CaixasController@index')
    ->name('listar_caixas');
Route::get('/caixas/criar', 'CaixasController@create')
    ->name('form_criar_caixa');
Route::post('/caixas/criar', 'CaixasController@store');
Route::delete('/caixas/remover/{id}', 'CaixasController@destroy');

Route::get('/bancos', 'BancosController@index')
    ->name('listar_bancos');
Route::get('/bancos/criar', 'BancosController@create')
    ->name('form_criar_banco');
Route::post('/bancos/criar', 'BancosController@store');
Route::delete('/bancos/remover/{id}', 'BancosController@destroy');

Route::get('/obras', 'ObrasController@index')
    ->name('listar_obras');
Route::get('/obras/criar', 'ObrasController@create')
    ->name('form_criar_obra');
Route::post('/obras/criar', 'ObrasController@store');
Route::delete('/obras/remover/{id}', 'ObrasController@destroy');

Route::get('/contas', 'ContasController@index')
    ->name('listar_contas');
Route::get('/contas/criar', 'ContasController@create')
    ->name('form_criar_conta');
Route::post('/contas/criar', 'ContasController@store');
Route::delete('/contas/remover/{id}', 'ContasController@destroy');

Route::get('/classes', 'ClassesController@index')
    ->name('listar_classes');

Route::get('/classes/criar', 'ClassesController@create')
    ->name('form_criar_classe');
Route::post('/classes/criar', 'ClassesController@store');
Route::delete('/classes/remover/{id}', 'ClassesController@destroy');

Route::get('/cargos', 'CargosController@index')
    ->name('listar_cargos');
Route::get('/cargos/criar', 'CargosController@create')
    ->name('form_criar_cargo');
Route::post('/cargos/criar', 'CargosController@store');
Route::delete('/cargos/remover/{id}', 'CargosController@destroy');

Route::get('/tipos', 'TiposController@index')
    ->name('listar_tipos');
Route::get('/tipos/criar', 'TiposController@create')
    ->name('form_criar_tipo');
Route::post('/tipos/criar', 'TiposController@store');
Route::delete('/tipos/remover/{id}', 'TiposController@destroy');

Route::get('/entradas', 'EntradasController@index');

Route::get('/saidas', 'SaidasController@listarSaidas');

Route::get('/pagamentos', 'PagamentosController@index');

Route::get('/recebimentos', 'RecebimentosController@index');

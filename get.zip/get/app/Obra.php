<?php


namespace App;


use Illuminate\Database\Eloquent\Model;

class Obra extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'id',
        'nome',
    ];
    protected $table = 'obras';

    public function funcionarios()
    {
        return $this->hasMany(Funcionario::class, 'obra_id');
    }
}

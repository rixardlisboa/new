<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classe extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'id',
        'nome',
    ];
    protected $table = 'classes';

    public function produtos()
    {
        return $this->hasMany(Produto::class, 'classe_id');
    }
}

<?php


namespace App;


use Illuminate\Database\Eloquent\Model;

class Produto extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'classe_id'
    ];
    protected $table = 'produtos';

    public function classe()
    {
        return $this->belongsTo(Classe::class, 'classe_id');
    }
}
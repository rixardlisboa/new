<?php

namespace App\Services;

use App\Produto;
use Illuminate\Support\Facades\DB;

class CriadorDeProduto
{
    public function criarproduto(string $nomeProduto):Produto
    {
        $nome = $nomeProduto;
        $preco = $request->preco;
        $quantidade = $request->quantidade;
        $unidade_de_venda = $request->unidade_de_venda;
        $fornecedor = $request->fornecedor;
        $ean = $request->ean;
        $descricao = $request->descricao;
        $categoria = $request->categoria;

        $produto = new Produto();

        $produto->nome = $nome;
        $produto->preco = $preco;
        $produto->quantidade = $quantidade;
        $produto->unidade_de_venda = $unidade_de_venda;
        $produto->fornecedor = $fornecedor;
        $produto->ean = $ean;
        $produto->descricao = $descricao;
        $produto->categoria = $categoria;

        $produto->save();

        return $produto;
    }
}

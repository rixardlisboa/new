<?php


namespace App\Http\Controllers;


use App\Funcionario;
use App\Cargo;
use App\Obra;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class FuncionariosController extends Controller
{
    public function index(Request $request) {
        $funcionarios = Funcionario::paginate(10);
        $mensagem = $request->session()->get('mensagem');
        return view('funcionarios.index', compact('funcionarios', 'mensagem'));
        
    }

    private function getCargos()
    {

        $cargosList = Cargo::all();

        return $cargosList;

    }    private function getObras()
    {

        $obrasList = Obra::all();

        return $obrasList;

    }
    public function create()
    {
        $cargos = $this->getCargos();
        $obras = $this->getObras();
        return view('funcionarios.create', compact('cargos', 'obras'));
    }

    public function store(Request $request)
    {
        $nome = $request->nome;
        $fantasia = $request->fantasia;
        $nasc = $request->nasc;
        $telefone = $request->telefone;
        $email = $request->email;
        $cep = $request->cep;
        $endereco = $request->endereco;
        $bairro = $request->bairro;
        $cidade = $request->cidade;
        $estado = $request->estado;
        $rg = $request->rg;
        $cpf = $request->cpf;
        $obs = $request->obs;
        $cargo = $request->cargo_id;
        $obra = $request->obra_id;

        $sexo = $request->sexo;
        $estadocivil = $request->estadocivil;
        $filhos = $request->filhos;
        $pis = $request->pis;
        $cnh = $request->cnh;
        $titulo = $request->titulo;
        $ct = $request->ct;
        $admissao = $request->admissao;
        $salario = $request->salario;

        $funcionario = new Funcionario();

        $funcionario->nome = $nome;
        $funcionario->fantasia = $fantasia;
        $funcionario->nasc = $nasc;
        $funcionario->telefone = $telefone;
        $funcionario->email = $email;
        $funcionario->cep = $cep;
        $funcionario->endereco = $endereco;
        $funcionario->bairro = $bairro;
        $funcionario->cidade = $cidade;
        $funcionario->estado = $estado;
        $funcionario->rg = $rg;
        $funcionario->cpf = $cpf;
        $funcionario->obs = $obs;
        $funcionario->cargo_id = $cargo;
        $funcionario->obra_id = $obra;

        $funcionario->sexo = $sexo;
        $funcionario->estadocivil = $estadocivil;
        $funcionario->filhos = $filhos;
        $funcionario->pis = $pis;
        $funcionario->cnh = $cnh;
        $funcionario->titulo = $titulo;
        $funcionario->ct = $ct;
        $funcionario->admissao = $admissao;
        $funcionario->salario = $salario;

        $funcionario->save();
        $request->session()
            ->flash(
                'mensagem',
                "Funcionário {$funcionario->id} criado com Sucesso {$funcionario->nome}
                ");
        return redirect('/funcionarios');
    }

    public function destroy (Request $request)

    {

        Funcionario::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Funcionario removido com sucesso"
            );

        return redirect()->route('listar_funcionarios');

    }

}

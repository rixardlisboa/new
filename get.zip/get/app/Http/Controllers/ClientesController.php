<?php


namespace App\Http\Controllers;

use App\Tipo;
use App\Cliente;
use Illuminate\Http\Request;
class ClientesController extends Controller
{
    public function index(Request $request)
    {
        $clientes = Cliente::paginate(10);

        $mensagem = $request->session()->get('mensagem');

        return view('clientes.index', compact('clientes', 'mensagem'));
    }

    public function create()
    {
        return view('clientes.create-edit');
    }

    public function store(Request $request)
    {
        $nome = $request->nome;
        $fantasia = $request->fantasia;
        $telefone = $request->telefone;
        $email = $request->email;
        $cep = $request->cep;
        $endereco = $request->endereco;
        $bairro = $request->bairro;
        $cidade = $request->cidade;
        $estado = $request->estado;
        $rg_ie = $request->rg_ie;
        $cpf_cnpj = $request->cpf_cnpj;
        $obs = $request->obs;
        $tipo = $request->tipo_id;

        $cliente = new Cliente();

        $cliente->nome = $nome;
        $cliente->fantasia = $fantasia;
        $cliente->telefone = $telefone;
        $cliente->email = $email;
        $cliente->cep = $cep;
        $cliente->endereco = $endereco;
        $cliente->bairro = $bairro;
        $cliente->cidade = $cidade;
        $cliente->estado = $estado;
        $cliente->rg_ie = $rg_ie;
        $cliente->cpf_cnpj = $cpf_cnpj;
        $cliente->obs = $obs;
        $cliente->tipo_id = $tipo;


        $cliente->save();
        $request->session()
            ->flash(
                'mensagem',
                "Cliente/Fornecedor {$cliente->id} criado com Sucesso {$cliente->nome}
                ");
        return redirect()->route('listar_clientes');
    }

    public function destroy(Request $request)

    {

        Cliente::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Cliente removido com sucesso"
            );

        return redirect()->route('listar_clientes');

    }

    public function show($id)
    {
        $cliente = $this->show($id);

        return view('clientes.show');
    }
}
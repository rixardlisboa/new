<?php


namespace App\Http\Controllers;
use App\Classe;
use Illuminate\Http\Request;

class ClassesController extends Controller
{
    public function index(Request $request) {
        $classes = Classe::paginate(10);
        $mensagem = $request->session()->get('mensagem');

        return view('classes.index', compact('classes', 'mensagem'));
    }

    public function create()
    {
        return view('classes.create');
    }
    public function store(Request $request)
    {
        $nome = $request->nome;

        $classe = new Classe();

        $classe->nome = $nome;

        $classe->save();

        $request->session()
            ->flash(
                'mensagem',
                "Classe {$classe->id} criada com Sucesso {$classe->nome}
                ");

        return redirect()->route('listar_classes');
    }

    public function destroy (Request $request)

    {

        Classe::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Caixa removido com sucesso"
            );

        return redirect()->route('listar_classes');

    }
}
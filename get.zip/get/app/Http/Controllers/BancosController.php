<?php


namespace App\Http\Controllers;
use App\Banco;
use Illuminate\Http\Request;

class BancosController extends Controller
{
    public function index(Request $request) {
        $bancos = Banco::paginate(10);

        $mensagem = $request->session()->get('mensagem');

        return view('bancos.index', compact('bancos', 'mensagem'));
    }

    public function create()
    {
        return view('bancos.create');
    }
    public function store(Request $request)
    {
        $nome = $request->nome;
        $agencia = $request->agencia;
        $tipo = $request->tipo;
        $conta = $request->conta;
        $digito = $request->digito;
        $nomebanco = $request->nomebanco;
        $saldo = $request->saldo;

        $banco = new Banco();

        $banco->nome = $nome;
        $banco->agencia  = $agencia ;
        $banco->tipo = $tipo;
        $banco->conta = $conta;
        $banco->digito = $digito;
        $banco->nomebanco = $nomebanco;
        $banco->saldo = $saldo;

        $banco->save();

        $request->session()
            ->flash(
                'mensagem',
                "Banco {$banco->id} criado com Sucesso {$banco->nome}
                ");

        return redirect()->route('listar_bancos');
    }

    public function destroy (Request $request)

    {

        Banco::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Banco removido com sucesso"
            );

        return redirect()->route('listar_bancos');

    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CriarTabelaFuncionarios extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('funcionarios', function (Blueprint $table){
            $table->increments('id');
            $table->string('nome');
            $table->string('fantasia');
            $table->string('nasc');
            $table->string('telefone');
            $table->string('email');
            $table->string('cep');
            $table->string('endereco');
            $table->string('bairro');
            $table->string('cidade');
            $table->string('estado');
            $table->string('rg');
            $table->string('cpf');
            $table->string('obs');
            $table->string('sexo');
            $table->string('estadocivil');
            $table->string('filhos');
            $table->string('pis');
            $table->string('cnh');
            $table->string('titulo');
            $table->string('ct');
            $table->string('admissao');
            $table->string('salario');

            $table->integer('cargo_id')->unsigned();
            $table->foreign('cargo_id')
                ->references('id')
                ->on('cargos')
                ->onDelete('cascade');

            $table->integer('obra_id')->unsigned();
            $table->foreign('obra_id')
                ->references('id')
                ->on('obras')
                ->onDelete('cascade');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('funcionarios');
    }
}
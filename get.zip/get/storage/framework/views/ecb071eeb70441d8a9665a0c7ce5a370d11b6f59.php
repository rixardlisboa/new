<?php $__env->startSection('cabecalho'); ?>
Ciente
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>


    <form method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="form-group">
                    <label for="nome">Cliente</label>
                    <input type="text" name="nome" value="" class="form-control" placeholder="Cliente" required>
                </div>
                <div class="form-group">
                    <label for="fantasia">Fantasia</label>
                    <input type="text" name="fantasia"  step="0.01" min="0" class="form-control" placeholder="Fantasia" required>
                </div>
                <div class="form-group">
                    <label for="tipo_id">Tipos</label>
                    <select class="form-control" name="tipo_id" onchange="exibeMsg(this.value);">
                        <option value="1">Pessoa Física</option>
                        <option value="2">Pessoa Jurídica</option>

                    </select>
                </div>
                <div class="form-group">
                    <span id="txt">RG</span>
                    <input type="number" name="rg_ie"  min="0" class="form-control" placeholder="" required>
                </div>
                <div class="form-group">
                    <span id="txt2">CPF</span>
                    <input type="number" name="cpf_cnpj" min="0" class="form-control" placeholder="" required>
                </div>
                <div class="form-group">
                    <label for="telefone">Telefone</label>
                    <input type="number" name="telefone"  class="form-control" placeholder="Telefone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" name="email"  step="0.01" min="0" class="form-control" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label for="cep">CEP</label>
                    <input type="number" name="cep"  min="0" class="form-control" placeholder="CEP" required>
                </div>
                <div class="form-group">
                    <label for="endereco">Endereço</label>
                    <input type="text" name="endereco"  min="0" class="form-control" placeholder="Endereço" required>
                </div>
                <div class="form-group">
                    <label for="bairro">Bairro</label>
                    <input type="text" name="bairro"  min="0" class="form-control" placeholder="Bairro" required>
                </div>
                <div class="form-group">
                    <label for="cidade">Cidade</label>
                    <input type="text" name="cidade"  min="0" class="form-control" placeholder="Cidade" required>
                </div>
                <div class="form-group">
                    <label for="estado">Estado</label>
                    <select class="form-control" name="estado">
                        <option></option>
                        <option>AC</option>
                        <option>AL</option>
                        <option>AP</option>
                        <option>AM</option>
                        <option>BA</option>
                        <option>CE</option>
                        <option>DF</option>
                        <option>ES</option>
                        <option>GO</option>
                        <option>MA</option>
                        <option>MT</option>
                        <option>MS</option>
                        <option>MG</option>
                        <option>PA</option>
                        <option>PB</option>
                        <option>PR</option>
                        <option>PE</option>
                        <option>PI</option>
                        <option>RJ</option>
                        <option>RN</option>
                        <option>RS</option>
                        <option>RO</option>
                        <option>RR</option>
                        <option>SC</option>
                        <option>SP</option>
                        <option>SE</option>
                        <option>TO</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="obs">Observações</label>
                    <input type="text" name="obs"  step="0.01" min="0" class="form-control" placeholder="Descrição do Funcionario" required>
                </div>

                <button class="btn btn-primary" style="background-color: #0D5C95; color: white;">Adicionar</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard Lisboa\Desktop\get\resources\views/clientes/exibir.blade.php ENDPATH**/ ?>
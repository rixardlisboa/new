<?php $__env->startSection('cabecalho'); ?>
    Cargos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <?php if(!empty($mensagem)): ?>
        <div class="alert alert-success" style="width: 50%">
            <?php echo e($mensagem); ?>

        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('form_criar_cargo')); ?>" class="btn btn-dark mb-2" style="margin-left: 90%; margin-top: -100px; background-color: #0D5C95; color: white;">Adicionar</a>


    <ul class="list-group" style="margin-top: -25px">
        <table class="table table-hover">
            <thead style="background-color: #9d9d9d; color: white;">
            <tr>
                <td>ID</td>
                <td>Nome</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($cargos as $cargo):?>
            <tr>
                <td><?= $cargo->id ?></td>
                <td style="width: 80%"><?= $cargo->nome ?></td>
                <td>
                    <form method="post" action="/cargos/remover/<?php echo e($cargo->id); ?>"
                          onsubmit="return confirm('Tem certeza que deseja remover <?php echo e(addslashes( $cargo->nome )); ?>?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
                <td></td>
                <td></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div style="position: absolute; top: 115%; left: 70%; "><?php echo e($cargos->links()); ?></div>

    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard Lisboa\Desktop\get\resources\views/cargos/index.blade.php ENDPATH**/ ?>
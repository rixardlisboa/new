<?php if(!empty($mensagem)): ?>
    <div class="alert alert-success">
        <?php echo e($mensagem); ?>

    </div>
<?php endif; ?><?php /**PATH C:\Users\Richard Lisboa\Desktop\get\resources\views/mensagem.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GET EMPREENDIMENTOS</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</head>
<body>

    <img style="margin-left: 42%; margin-top: 10%;" src="https://static.wixstatic.com/media/9688f3_74ef83a2b16e4356814310e9d008e52f~mv2.png/v1/fill/w_184,h_59,al_c,q_80,usm_0.66_1.00_0.01/01.webp" width="15%" height="60"  class="d-inline-block align-top mr-5" alt="">

    <?php echo $__env->make('erros', ['errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form method="post" style="width: 300px; margin-left: 39%; margin-top: %;">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="email"><br></label>
            <input type="email" name="email" id="email" required class="form-control" placeholder="Usuário">
        </div>

                <div class="form-group" style="padding-top: -20px;"
                    <label for="password"></label>
                    <input type="password" name="password" id="password" required min="1" class="form-control" placeholder="Senha">


                <button type="submit" class="btn mb-2" style="background-color: #0D5C95; margin-top: 15px; color: white; width: 100%">
                    Entrar
                </button>
<!--
                <a href="/registrar" class="btn btn-secondary mt-3">
                    Registrar-se
                </a></div>-->
            </form>

    </body>
    </html><?php /**PATH C:\Users\Richard Lisboa\Desktop\get\resources\views/entrar/index.blade.php ENDPATH**/ ?>
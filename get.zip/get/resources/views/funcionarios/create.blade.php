@extends('layout')

@section('cabecalho')
Adicionar Funcionario
@endsection

@section('conteudo')
<form method="post">
    @csrf
    <div>

        <div class="form-row">

            <div class="form-group col-md-12">
                <H4 style="text-align: center;">Cadastrais</H4></div>
            <div class="form-group col-md-10"></div>

            <div class="form-group col-md-8">
                <label for="nome">Nome</label>
                <input type="text" name="nome"  class="form-control" placeholder="Nome" required>
            </div>
            <div class="form-group col-md-4">
                <label for="fantasia">Apelido</label>
                <input type="text" name="fantasia"  step="0.01" min="0" class="form-control" placeholder="Apelido" required>
            </div>
            <div class="form-group col-md-3">
                <label for="nasc">Data de Nascimento</label>
                <input type="date" name="nasc"  min="0" class="form-control" placeholder="Data de Nascimento" required>
            </div>
            <div class="form-group col-md-3">
                <label for="cep">CEP</label>
                <input type="number" name="cep"  min="0" class="form-control" placeholder="CEP" required>
            </div>
            <div class="form-group col-md-6">
                <label for="endereco">Endereço</label>
                <input type="text" name="endereco"  min="0" class="form-control" placeholder="Endereço" required>
            </div>
            <div class="form-group col-md-3">
                <label for="bairro">Bairro</label>
                <input type="text" name="bairro"  min="0" class="form-control" placeholder="Bairro" required>
            </div>
            <div class="form-group col-md-5">
                <label for="cidade">Cidade</label>
                <input type="text" name="cidade"  min="0" class="form-control" placeholder="Cidade" required>
            </div>
            <div class="form-group col-md-1">
                <label for="estado">Estado</label>
                <select class="form-control" name="estado" required>
                    <option></option>
                    <option>AC</option>
                    <option>AL</option>
                    <option>AP</option>
                    <option>AM</option>
                    <option>BA</option>
                    <option>CE</option>
                    <option>DF</option>
                    <option>ES</option>
                    <option>GO</option>
                    <option>MA</option>
                    <option>MT</option>
                    <option>MS</option>
                    <option>MG</option>
                    <option>PA</option>
                    <option>PB</option>
                    <option>PR</option>
                    <option>PE</option>
                    <option>PI</option>
                    <option>RJ</option>
                    <option>RN</option>
                    <option>RS</option>
                    <option>RO</option>
                    <option>RR</option>
                    <option>SC</option>
                    <option>SP</option>
                    <option>SE</option>
                    <option>TO</option>
                </select>
            </div>
            <div class="form-group col-md-3">
                <label for="telefone">Telefone</label>
                <input type="tel" name="telefone"  class="form-control" placeholder="Telefone" required>
            </div>
            <div class="form-group col-md-5">
                <label for="email">Email</label>
                <input type="email" name="email" value="Email" step="0.01" min="0" class="form-control" placeholder="Email">
            </div>

            <div class="form-group col-md-12">
            <H4 style="text-align: center;">Pessoais</H4></div>
            <div class="form-group col-md-10"></div>

            <div class="form-group col-md-4">
                <label for="sexo">Sexo</label>
                <select class="form-control" name="sexo" required>
                    <option>Masculino</option>
                    <option>Feminino</option>
                </select>
            </div>
                <div class="form-group col-md-5">
                <label for="estadocivil">Estado Civil</label>
                <select class="form-control" name="estadocivil" required>
                   <option>Casado(a)</option>
                   <option>Solteiro(a)</option>
                   <option>Divorciado(a)</option>
                   <option>Viúvo(a)</option>
                   <option>União Estável(a)</option>
                </select>
                </div>
                    <div class="form-group col-md-3">
                <label for="filhos">Filhos</label>
                <input type="number" name="filhos" value="0" min="0" class="form-control" placeholder="Filhos" required>
            </div>

            <div class="form-group col-md-12">
                <H4 style="text-align: center;">Documentos</H4></div>
            <div class="form-group col-md-10"></div>

            <div class="form-group col-md-4">
                <label for="rg">RG</label>
                <input type="number" name="rg"  min="0" class="form-control" placeholder="RG" required>
            </div>
            <div class="form-group col-md-4">
                <label for="cpf">CPF</label>
                <input type="number" name="cpf"  min="0" class="form-control" placeholder="CPF" required>
            </div>
            <div class="form-group col-md-4">
                    <label for="pis">PIS</label>
                    <input type="number" name="pis" value="0"  min="0" class="form-control" placeholder="PIS">
                </div>
            <div class="form-group col-md-4">
                    <label for="cnh">CNH</label>
                    <input type="number" name="cnh" value="0" min="0" class="form-control" placeholder="CNH">
                </div>
            <div class="form-group col-md-4">
                    <label for="titulo">Título de Eleitor</label>
                    <input type="number" name="titulo" value="0" min="0" class="form-control" placeholder="Titulo de Eleitor" >
                </div>
            <div class="form-group col-md-4">
                    <label for="ct">Carteira de Trabalho</label>
                    <input type="number" name="ct" value="0" min="0" class="form-control" placeholder="Carteira de Trabalho" >
                </div>

            <div class="form-group col-md-12">
                <H4 style="text-align: center;">Empresa</H4></div>
            <div class="form-group col-md-10"></div>

            <div class="form-group col-md-3">
                    <label for="admissao">Adimissão</label>
                    <input type="date" name="admissao"  min="0" class="form-control" placeholder="Adimissão" required>
                </div>
            <div class="form-group col-md-3">
                <label for="salario">Salário</label>
                <input type="number" name="salario"  min="0" class="form-control" placeholder="Salário" required>
            </div>
            <div class="form-group col-md-3">
                    <label for="cargo_id">Cargos do Funcionario</label>
                        <select class="form-control" name="cargo_id" required>
                            <option>Selecione o Cargo</option>
                        @foreach($cargos as $cargo)
                                <option value="{{$cargo->id }}">{{$cargo->nome}}</option>
                            @endforeach

                    </select>
                </div>
            <div class="form-group col-md-3">
                    <label for="obra_id">Obras</label>
                        <select class="form-control" name="obra_id" required>
                            <option>Selecione a Obra</option>
                        @foreach($obras as $obra)
                                <option value="{{$obra->id }}">{{$obra->nome}}</option>
                            @endforeach

                    </select>
                </div>
            <div class="form-group col-md-12">
                <label for="obs">Historico</label>
                <input type="text" name="obs" value="Histórico do Funcionário" step="0.01" min="0" class="form-control" placeholder="Descrição do Funcionario">
            </div>

            <button class="btn btn-primary" style="background-color: #0D5C95; color: white;">Adicionar</button>
        </div>
    </div>
</form>
@endsection
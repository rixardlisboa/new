@extends('layout')

@section('cabecalho')
Adicionar Cliente ou Fornecedor
@endsection

@section('conteudo')

@endsection
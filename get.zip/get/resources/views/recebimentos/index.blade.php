@extends('layout')

@section('cabecalho')
    A Receber
@endsection

@section('conteudo')

    @if(!empty($mensagem))
        <div class="alert alert-success" style="width: 50%">
            {{ $mensagem }}
        </div>
    @endif

        <a href="{{route('form_criar_cliente')}}" class="btn btn-dark mb-2" style="margin-left: 90%; margin-top: -100px; background-color: #0D5C95; color: white;">Adicionar</a>


    <ul class="list-group" style="margin-top: -25px">
        <thead style="background-color: #9d9d9d; color: white;">
            <thead style="background-color: #808080;">
            <tr>
                <td>Origem</td>
                <td>S</td>
                <td>Nome</td>
                <td>Emissão</td>
                <td>Vencimento</td>
                <td>Valor</td>
                <td>Desconto</td>
                <td>Juros</td>
                <td>Multa</td>
                <td>Total</td>
                <td>Valor Pago</td>
                <td>Data de Pgto</td>
                <td>Caixa</td>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($recebimentos as $recebimento):?>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div style="position: absolute; top: 115%; left: 70%; ">{{ $recebimentos->links() }}</div>

    </ul>
@endsection
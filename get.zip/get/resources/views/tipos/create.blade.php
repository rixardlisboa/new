@extends('layout')

@section('cabecalho')
    Adicionar Tipo
@endsection

@section('conteudo')
    <form method="post">
        @csrf
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" name="nome"  class="form-control" placeholder="Tipo" required>
                </div>
                <button class="btn btn-primary" style="background-color: #0D5C95; color: white;">Adicionar</button>
            </div>
        </div>
    </form>
@endsection
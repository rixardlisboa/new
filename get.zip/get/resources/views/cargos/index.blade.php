@extends('layout')

@section('cabecalho')
    Cargos
@endsection

@section('conteudo')

    @if(!empty($mensagem))
        <div class="alert alert-success" style="width: 50%">
            {{ $mensagem }}
        </div>
    @endif

    <a href="{{route('form_criar_cargo')}}" class="btn btn-dark mb-2" style="margin-left: 90%; margin-top: -100px; background-color: #0D5C95; color: white;">Adicionar</a>


    <ul class="list-group" style="margin-top: -25px">
        <table class="table table-hover">
            <thead style="background-color: #9d9d9d; color: white;">
            <tr>
                <td>ID</td>
                <td>Nome</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($cargos as $cargo):?>
            <tr>
                <td><?= $cargo->id ?></td>
                <td style="width: 80%"><?= $cargo->nome ?></td>
                <td>
                    <form method="post" action="/cargos/remover/{{ $cargo->id}}"
                          onsubmit="return confirm('Tem certeza que deseja remover {{ addslashes( $cargo->nome )}}?')">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
                    </form>
                </td>
                <td></td>
                <td></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div style="position: absolute; top: 115%; left: 70%; ">{{ $cargos->links() }}</div>

    </ul>
@endsection